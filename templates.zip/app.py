from flask import Flask, render_template, url_for, redirect, request

app = Flask(__name__)

serials = serials = [ {"id":1, "title":"Гра в кальмара","year":2023,"genre":"Бойовик","description":"Гра про багатих і бідних"}, {"id":2, "title":"Бріджертон","year":2022,"genre":"Драма","description":"Історія про кохання та інтриги в аристократичному Лондоні"}, {"id":3, "title":"Відьмак","year":2021,"genre":"Фентезі","description":"Мисливець на монстрів бореться за виживання у жорстокому світі"}, {"id":4, "title":"Дивні дива","year":2022,"genre":"Фантастика","description":"Діти стикаються з таємничими силами та паралельними світами"}, {"id":5, "title":"Корона","year":2020,"genre":"Історична драма","description":"Життя та правління королеви Єлизавети II"}, {"id":6, "title":"Темні початки","year":2021,"genre":"Фентезі","description":"Дівчинка вирушає у подорож паралельними світами"}, {"id":7, "title":"Локі","year":2021,"genre":"Фантастика","description":"Бог хитрощів створює хаос у мультивсесвіті"}, {"id":8, "title":"Мандалорець","year":2020,"genre":"Фантастика","description":"Мисливець за головами піклується про таємничу дитину"}, {"id":9, "title":"Хід королеви","year":2020,"genre":"Драма","description":"Історія шахістки, яка бореться з залежністю та долею"}, {"id":10, "title":"Офіс","year":2008,"genre":"Комедія","description":"Смішні будні працівників офісу"}, {"id":11, "title":"Дім дракона","year":2022,"genre":"Фентезі","description":"Передісторія 'Гри престолів' про династію Таргарієнів"}, {"id":12, "title":"Гра престолів","year":2019,"genre":"Фентезі","description":"Боротьба за владу у світі Семи Королівств"}, {"id":13, "title":"Фарго","year":2020,"genre":"Кримінал","description":"Кримінальні історії з чорним гумором"}, {"id":14, "title":"Озарк","year":2021,"genre":"Трилер","description":"Фінансист відмиває гроші для картелю"}, {"id":15, "title":"Картковий будинок","year":2018,"genre":"Драма","description":"Безжалісна боротьба за владу у Вашингтоні"}, {"id":16, "title":"Дивний світ","year":2022,"genre":"Пригоди","description":"Сім'я вирушає в загадкову експедицію"}, {"id":17, "title":"Тьма","year":2020,"genre":"Фантастика","description":"Місто стикається з таємницями подорожей у часі"}, {"id":18, "title":"Наркос","year":2019,"genre":"Кримінал","description":"Історія Пабло Ескобара та наркокартелю"}, {"id":19, "title":"Шерлок","year":2017,"genre":"Детектив","description":"Сучасні розслідування Шерлока Холмса"}, {"id":20, "title":"Доктор Хаус","year":2012,"genre":"Драма","description":"Геніальний лікар із складним характером"}, {"id":21, "title":"Чорне дзеркало","year":2021,"genre":"Фантастика","description":"Антологія про темний бік технологій"}, {"id":22, "title":"Паперовий дім","year":2020,"genre":"Кримінал","description":"Зухвале пограбування Королівського монетного двору"}, {"id":23, "title":"Вікінги","year":2019,"genre":"Історія","description":"Жорстоке життя та завоювання скандинавів"}, {"id":24, "title":"Справжній детектив","year":2019,"genre":"Детектив","description":"Напружені розслідування складних злочинів"}, {"id":25, "title":"Ходячі мерці","year":2021,"genre":"Жахи","description":"Група людей виживає серед зомбі-апокаліпсису"}, {"id":26, "title":"Кобра Кай","year":2021,"genre":"Драма","description":"Продовження історії 'Карате пацана'"}, {"id":27, "title":"Академія Амбрелла","year":2020,"genre":"Фантастика","description":"Діти з суперсилами намагаються врятувати світ"}, {"id":28, "title":"Люцифер","year":2021,"genre":"Фентезі","description":"Диявол вирішує жити серед людей та допомагати поліції"}, {"id":29, "title":"Супернатурал","year":2020,"genre":"Фентезі","description":"Двоє братів полюють на демонів та чудовиськ"}, {"id":30, "title":"Гострі козирки","year":2020,"genre":"Кримінал","description":"Бандитська сім'я у Бірмінгемі після війни"} ]
@app.route('/')
def index():
    return render_template("index.html", serials=serials)

@app.route('/serial/<int:serial_id>/')
def serial_detail(serial_id):
    serial = next((s for s in serials if s["id"] == serial_id), None)
    if serial:
        return render_template("serial.html", serial=serial)
    return "<h1>Серіал не знайдено</h1>", 404

@app.route('/add', methods=['GET', 'POST'])
def add_serial():
    if request.method == 'POST':
        new_id = max(s["id"] for s in serials) + 1
        new_serial = {
            "id": new_id,
            "title": request.form["title"],
            "year": int(request.form["year"]),
            "genre": request.form["genre"],
            "description": request.form["description"],
        }
        serials.append(new_serial)
        return redirect(url_for("index"))
    return render_template("add.html")

@app.route('/genres/')
def genres():
    genres_list = sorted(set(s["genre"] for s in serials))
    return render_template("genres.html", genres=genres_list)

@app.route('/genre/<genre_name>/')
def genre_serials(genre_name):
    filtered = [s for s in serials if s["genre"].lower() == genre_name.lower()]
    return render_template("genre_serial.html", genre=genre_name, serials=filtered)

@app.route('/about/')
def about():
    return render_template("about.html")

if __name__ == "__main__":
    app.run(debug=True)
